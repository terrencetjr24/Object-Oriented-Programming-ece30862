#ifndef ALARM_H
#define ALARM_H
#include "Subject.h"
#include "Observer.h"

#endif /* ALARM_H */
