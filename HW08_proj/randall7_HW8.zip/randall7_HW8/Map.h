#ifndef MAP_H
#define MAP_H
#include "Subject.h"
#include "Observer.h"

#endif /* MAP_H */
