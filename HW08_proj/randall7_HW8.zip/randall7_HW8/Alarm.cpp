#include <iostream>
#include <cmath>
#include "Alarm.h"

Alarm::Alarm(Subject * s, int i, double xx, double yy, double alarm) 
     : {  
}

Alarm::~Alarm( ) { }

}
