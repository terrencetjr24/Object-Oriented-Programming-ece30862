#include "Base.h"
#include <iostream>
using namespace std;

Base::Base( ) { }
Base::~Base( ) { }

// include necessary function definitions here
void Base::f1()
{
    cout << "Base f1\n";
}

void Base::f2()
{
    cout << "Base f2\n";
}
