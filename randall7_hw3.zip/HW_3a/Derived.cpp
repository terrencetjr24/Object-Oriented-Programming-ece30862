#include "Derived.h"
#include <iostream>
using namespace std;

Derived::Derived( ) { }
Derived::~Derived( ) { }

// add necessary functions here
void Derived::f2()
{
    cout << "Derived f2\n";
}
